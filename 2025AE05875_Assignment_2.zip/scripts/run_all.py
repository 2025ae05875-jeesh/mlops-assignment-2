"""Run Tasks 1-3 end to end without the notebook (same code as the notebook).

Usage:  python scripts/run_all.py
"""

from eduassist import config
from eduassist.config import get_settings, load_questions
from eduassist.llm_client import LLMClient
from eduassist.workflow import setup_mlflow, task1_task2, task3, write_metadata


def main() -> None:
    s = get_settings()
    setup_mlflow(s)
    client = LLMClient(s)
    questions = load_questions()
    config.OUTPUTS_DIR.mkdir(exist_ok=True)
    print(f"Provider={s.provider} model={s.model} tracking={s.tracking_uri}")

    t12 = task1_task2(client, questions)
    print("\nTask 1 latency stats (s):",
          {k: round(v, 3) for k, v in t12["latency_stats"].items()})
    print(f"Task 2 avg cost/request: {t12['avg_cost']:.8f} {s.currency}  |  "
          f"10,000 requests/month: {t12['monthly_cost']:.4f} {s.currency}")

    t3 = task3(client, questions)
    print("\nTask 3 comparison:")
    print(t3["table"].drop(columns=["run_id"]).to_string(index=False))
    print(f"\nPromoted {t3['best']['prompt_version']} "
          f"(registry version {t3['production_version']}) to alias 'production'")
    write_metadata(client)
    print("Outputs written to", config.OUTPUTS_DIR)


if __name__ == "__main__":
    main()
